There are 3 sets of brain masks, they are all the same; except sampled in different spaces.


s-*-in-2009c-dims
These are the 14 brain masks sampled in t1 space (MNI152NLim2009cAsym)

*-in-func1-space
These are samled in the space of non-AROMA scans, in which fmriPREP outputs the images in input resolution

*-in-func2-space
These are sampled in the space of the AROMA'ed scans -- in which motion/ICA correction has been applied; resultion is set to 2x2x2 mm.

